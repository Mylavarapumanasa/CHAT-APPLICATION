const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('A user connected');

  socket.on('new-user', (username) => {
    socket.username = username;
    socket.broadcast.emit('user-connected', username);
  });

  socket.on('chat-message', (msg) => {
    io.emit('chat-message', { msg, username: socket.username });
  });

  socket.on('disconnect', () => {
    if (socket.username) {
      socket.broadcast.emit('user-disconnected', socket.username);
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});