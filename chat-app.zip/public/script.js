const socket = io();
const form = document.getElementById('chat-form');
const msgInput = document.getElementById('msg');
const messages = document.getElementById('messages');

const username = prompt("Enter your name:");
socket.emit('new-user', username);

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const msg = msgInput.value;
  if (msg.trim()) {
    addMessage(`You: ${msg}`);
    socket.emit('chat-message', msg);
    msgInput.value = '';
  }
});

socket.on('chat-message', data => {
  if (data.username !== username) {
    addMessage(`${data.username}: ${data.msg}`);
  }
});

socket.on('user-connected', name => {
  addMessage(`${name} joined the chat`);
});

socket.on('user-disconnected', name => {
  addMessage(`${name} left the chat`);
});

function addMessage(msg) {
  const div = document.createElement('div');
  div.textContent = msg;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}
